# xiaoliu_run_tests（脚手架）

输入：{ scope: lint|unit|integration|all, coverage_threshold?: number }
输出：{ success: boolean, coverage?: number, reports: [paths] }
