# pre-commit（模板）
# 运行：lint/format、semgrep、gitleaks；失败即阻断
