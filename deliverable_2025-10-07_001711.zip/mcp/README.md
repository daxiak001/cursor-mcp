# MCP 工具脚手架说明

- 目录：mcp/tools/
- 工具：xiaoliu_search_codebase.md, xiaoliu_write_code.md, xiaoliu_respond_to_user.md, xiaoliu_run_tests.md
- 参考契约：../接口/工具契约.schemas.json
