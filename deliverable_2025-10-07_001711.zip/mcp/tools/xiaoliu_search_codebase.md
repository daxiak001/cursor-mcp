# xiaoliu_search_codebase（脚手架）

输入：{ query: string, scope?: string }
输出：{ found: number, matches: [{file, summary, similarity}] }
规则：IR-010 开发前查重
