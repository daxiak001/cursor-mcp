# dashboard.md（简版仪表板）
- 时间：
- 最近[#TASK]：
- 最近[#TEST]：
- 最近[#STAGE]：
- 质量摘要：reports/quality-summary.txt
- 预检：reports/preflight_placeholder.txt
- 周期：reports/dev_cycle.txt
