git config commit.template .gitmessage.txt
